<?php
/*
*
* Template Name: login
*
*
*/
get_header();
?>

<h1 style="margin:100px;">
  Login
</h1>

<div style="margin:50px;">
<?php
 woof_custom_login();

?>
</div>